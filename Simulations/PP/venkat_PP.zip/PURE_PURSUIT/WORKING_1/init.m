
Xp_0 = 0;
Yp_0 = 0;
Vp_0 = 100;
Alpha_p = 60*pi/180;

Xt_0 = 500;
Yt_0 = 500;
Vt_0 = 60;
Alpha_t = -90*pi/180;

t0 = 0.0;
tf = 500;
dt = 0.01;